var assignMinionRoles, commands, coordsNextTo, gameStatus, getClosestResource, goMining, isNextTo, mineResource, models, moveAndDestroy, moveAround, moveNextTo,
	__hasProp = {}.hasOwnProperty;

commands = require('./commands');
models = require('./models');

gameStatus = {};

module.exports.gameResults = function(gameResults) {
	gameResults = JSON.parse(gameResults);
	console.log("Incoming results for game " + gameResults.id);
	if (gameResults.won) {
		return console.log("I won!!!!");
	} else {
		console.log("I lose :(");
		if (!gameResults.match_over) {
			return console.log("maybe I should try a different strategy...");
		}
	}
};

module.exports.matchStarting = function(matchInfo) {
	matchInfo = JSON.parse(matchInfo);
	return console.log("I am playing " + matchInfo.opponent_name + " in a best of " + matchInfo.best_of + " series");
};

module.exports.processGameStatus = function(jsonStatus) {
	var cmds, e, minionRoles;
	try {
		gameStatus = new models.Status(jsonStatus);
		models.Status.debug(gameStatus);

		if (gameStatus.round === 1) {
			return console.log("I should probably reset any game-specific data I am holding...");
		}

		cmds = new commands.Commands(); //commands to be sent to the server

		if (gameStatus.round === 1) {
			cmds.append(new commands.BuildLesserMinionCommand(1, 1, 1, 4, 2, 1, gameStatus.base.x + 1, gameStatus.base.y - 1));
		} else {
			cmds.append(new commands.BuildLesserMinionCommand(3, 2, 1, 1, 2, 1, gameStatus.base.x + 1, gameStatus.base.y - 1));
		}

		if (gameStatus.enemyBase) {
			console.log("ENEMY BASE SPOTTED CAPTAIN!");
		}

		minionRoles = assignMinionRoles(gameStatus);

		cmds.append(goMining(minionRoles.miners));

		if (gameStatus.enemyBase) {
			cmds.append(moveAndDestroy(minionRoles.attackers));
		} else {
			cmds.append(moveAround(minionRoles.attackers));
		}
		
		cmds.debug("(round " + gameStatus.round + ")");
		return cmds.stringify(); //convert to string for server response
	} catch (e) {
		console.log("ERROR: " + e);
		return "";
	}
};

moveAround = function(minions) {
	var cmmds, directions, minion, randomDirection, i;
	cmmds = new commands.Commands();
	for (i = 0; i < minions.length; i++) {
		minion = minions[i];
		cmmds.append(new commands.MoveCommand(minion.id, models.Directions.East)); //bug for those who start in the east
		directions = [models.Directions.North, models.Directions.South, models.Directions.East, models.Directions.West];
		randomDirection = Math.floor(Math.random() * 4);
		cmmds.append(new commands.MoveCommand(minion.id, directions[randomDirection]));
		randomDirection = Math.floor(Math.random() * 4);
		cmmds.append(new commands.MoveCommand(minion.id, directions[randomDirection]));
	}
	return cmmds;
};

goMining = function(minions) {
	var closestResource, cmmds, minion, moveCommand, i;
	cmmds = new commands.Commands();
	for (i = 0; i < minions.length; i++) {
		minion = minions[i];
		if (minion.gold) { //carrying!
			moveCommand = moveNextTo(minion, gameStatus.base);
			if (moveCommand) {
				cmmds.append(moveCommand);
			}
		} else { //go mine!
			closestResource = getClosestResource(minion);
			if (closestResource) {
				moveCommand = moveNextTo(minion, closestResource);
				if (moveCommand) {
					cmmds.append(moveCommand);
				} else { //no need to move, lets mine
					cmmds.append(mineResource(minion, closestResource));
				}
			}
		}
	}
	return cmmds;
};

coordsNextTo = function(fromX, fromY, toX, toY) {
	var aboveOrBelow, toSide;
	toSide = Math.abs(fromX - toX) === 1 && Math.abs(fromY - toY) === 0;
	aboveOrBelow = Math.abs(fromX - toX) === 0 && Math.abs(fromY - toY) === 1;
	return toSide || aboveOrBelow;
};

isNextTo = function(fromEntity, toEntity) {
	var fromSize, toSize;
	fromSize = fromEntity.size || 1;
	toSize = toEntity.size || 1;
	if (fromSize === 1 && toSize === 1) {
		return coordsNextTo(fromEntity.x, fromEntity.y, toEntity.x, toEntity.y);
	}
	console.log("I might be next to it, but lets check that lovely top left corner");
	return coordsNextTo(fromEntity.x, fromEntity.y, toEntity.x, toEntity.y);
};

moveNextTo = function(minion, toEntity) {
	var directions, randomDirection;
	if (isNextTo(minion, toEntity)) {
		return false; //no need!
	}
	directions = [];
	if (minion.x - toEntity.x < 0) {
		directions.push(models.Directions.East); //need to move east
	}
	if (minion.x - toEntity.x > 0) {
		directions.push(models.Directions.West);
	}
	if (minion.y - toEntity.y > 0) {
		directions.push(models.Directions.North);
	}
	if (minion.y - toEntity.y < 0) {
		directions.push(models.Directions.South);
	}
	randomDirection = Math.floor(Math.random() * directions.length);

	//enhancement, move to closest coordinate if toEntity is a base?

	return new commands.MoveCommand(minion.id, directions[randomDirection]);
};

moveAndDestroy = function(minions) {
	var cmmds, minion, moveCommand, i;
	cmmds = new commands.Commands();
	for (i = 0; i < minions.length; i++) {
		minion = minions[i];
		moveCommand = moveNextTo(minion, gameStatus.enemyBase);
		if (moveCommand) {
			cmmds.append(moveCommand);
		} else {
			cmmds.append(new commands.AttackCommand(minion.id, gameStatus.enemyBase.x, gameStatus.enemyBase.y));
		}
	}
	return cmmds;
};

assignMinionRoles = function(status) {
	var minion, roles, i;
	roles = {
		miners: [],
		attackers: []
	};
	for (i = 0; i < status.minions.length; i++) {
		minion = status.minions[i];
		if (!minion.isDivergent) { //safety check. you don't want them uprooting your society or anything drastic.
			if (minion.mining > 30) {
				roles.miners.push(minion);
			} else {
				roles.attackers.push(minion);
			}
		}
	}
	return roles;
};

getClosestResource = function(minion) {
	var aResource, resourceTarget;
	resourceTarget = null;
	// use the x, y of the minion to find the closest resource
	for (aResource in gameStatus.resources) {
		if (!__hasProp.call(gameStatus.resources, aResource)) continue; 
		resourceTarget = gameStatus.resources[aResource]; //just kidding! use the last one in the list
	}
	return resourceTarget;
};

mineResource = function(minion, resource) {
	return new commands.MineCommand(minion.id, resource.x, resource.y);
};
