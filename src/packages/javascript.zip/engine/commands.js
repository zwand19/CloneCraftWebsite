var AttackCommand, BuildGreaterMinionCommand, BuildLesserMinionCommand, Commands, HandOffCommand, MineCommand, MoveCommand;

exports.AttackCommand = AttackCommand = (function() {
  function AttackCommand(minionId, x, y) {
    this.minionId = minionId;
    this.commandName = 'attack';
    this.params = {
      x: x,
      y: y
    };
  }

  return AttackCommand;

})();

exports.BuildLesserMinionCommand = BuildLesserMinionCommand = (function() {
  function BuildLesserMinionCommand(damageStat, rangeStat, healthStat, miningStat, speedStat, visionStat, x, y) {
    if ((damageStat + rangeStat + healthStat + miningStat + speedStat + visionStat) > 10) {
      console.error("WARN: Lesser Minion can only have up to 10 skill points!");
    }
    this.commandName = 'build lesser';
    this.minionId = null;
    this.params = {
      x: x,
      y: y,
      stats: {
        d: damageStat,
        r: rangeStat,
        h: healthStat,
        m: miningStat,
        s: speedStat,
        v: visionStat
      }
    };
  }

  return BuildLesserMinionCommand;

})();

exports.BuildGreaterMinionCommand = BuildGreaterMinionCommand = (function() {
  function BuildGreaterMinionCommand(damageStat, rangeStat, healthStat, miningStat, speedStat, visionStat, x, y) {
    if ((damageStat + rangeStat + healthStat + miningStat + speedStat + visionStat) > 19) {
      console.error("WARN: Greater Minion can only have up to 19 skill points!");
    }
    this.commandName = 'build greater';
    this.minionId = null;
    this.params = {
      x: x,
      y: y,
      stats: {
        d: damageStat,
        r: rangeStat,
        h: healthStat,
        m: miningStat,
        s: speedStat,
        v: visionStat
      }
    };
  }

  return BuildGreaterMinionCommand;

})();

exports.HandOffCommand = HandOffCommand = (function() {
  function HandOffCommand(handerId, handeeId) {
    this.commandName = 'hand off';
    this.minionId = handerId;
    this.params = {
      minionId: handeeId
    };
  }

  return HandOffCommand;

})();

exports.MineCommand = MineCommand = (function() {
  function MineCommand(minionId, x, y) {
    this.minionId = minionId;
    this.commandName = 'mine';
    this.params = {
      x: x,
      y: y
    };
  }

  return MineCommand;

})();

exports.MoveCommand = MoveCommand = (function() {
  function MoveCommand(minionId, direction) {
    this.minionId = minionId;
    this.commandName = 'move';
    if (['N', 'S', 'E', 'W'].indexOf(direction) === -1) {
      console.error("WARN: " + direction + " is not a valid direction!");
    }
    this.params = {
      direction: direction
    };
  }

  return MoveCommand;

})();

exports.Commands = Commands = (function() {
  function Commands(someCommands) {
    this.commandsArray = [];

    this.append = function(someCommands) {
      var aCommand, i, results;
      if (Array.isArray(someCommands)) {
        results = [];
        for (i = 0; i < someCommands.length; i++) {
          aCommand = someCommands[i];
          results.push(this.append(aCommand));
        }
        return results;
      } else if (someCommands !== null && typeof someCommands === 'object') {
        if (someCommands.commandName) {
          return this.commandsArray.push(someCommands);
        } else if (someCommands.commandsArray) {
          return this.append(someCommands.commandsArray);
        } else {
          return console.error("WARN: cannot append commands. Not an recognized object!");
        }
      } else {
        return console.error("WARN: cannot append commands. Not an array or object!");
      }
    };

    this.stringify = function() {
      return JSON.stringify(this.commandsArray);
    };
    
    this.debug = function(otherText) {
      if (otherText == null) {
        otherText = "";
      }
      console.log("<-- DEBUG COMMANDS " + otherText + " -->");
      console.log(JSON.stringify(this.commandsArray, null, 4));
      return console.log("</- DEBUG COMMANDS " + otherText + " -/>");
    };
  }

  return Commands;

})();
