var Base, Minion, Resource, Status;

exports.Base = Base = (function() {
	function Base(id, gold, health, x, y) {
		this.id = id;
		this.gold = gold;
		this.health = health;
		this.x = x;
		this.y = y;
		this.size = 3;
	}

	return Base;

})();

exports.Minion = Minion = (function() {
	function Minion(id, x, y, gold, damage, health, mining, range, speed, vision) {
		this.id = id;
		this.x = x;
		this.y = y;
		this.gold = gold;
		this.damage = damage;
		this.health = health;
		this.mining = mining;
		this.range = range;
		this.speed = speed;
		this.vision = vision;
	}

	return Minion;

})();

exports.Resource = Resource = (function() {
	function Resource(id, x, y) {
		this.id = id;
		this.x = x;
		this.y = y;
	}

	return Resource;

})();

exports.Status = Status = (function() {
	function Status(status) {
		var b, m, r;
		if (typeof status === "string") {
			status = JSON.parse(status);
		}
		this.gameId = status.gameId;
		this.round = status.round;
		this.boardWidth = status.board.w;
		this.boardHeight = status.board.h;
		this.nextMinionId = status.nextMinionId;
		this.minions = [];
		for (i = 0; i < status.minions.length; i++) {
			m = status.minions[i];
			this.minions.push(new Minion(m.id, m.x, m.y, m.g, m.d, m.hp, m.mi, m.r, m.sp, m.vi));
		}
		this.enemyMinions = [];
		for (j = 0; j < status.vision.minions.length; j++) {
			m = status.vision.minions[j];
			this.enemyMinions.push(new Minion(m.id, m.g, m.d, m.hp, m.mi, m.r, m.sp, m.vi));
		}
		this.base = new Base(status.base.id, status.base.g, status.base.h, status.base.x, status.base.y);
		this.enemyBase = null;
		if (status.vision.bases.length > 0) {
			b = status.vision.bases[0];
			this.enemyBase = new Base(b.id, b.g, b.h, b.x, b.y);
		}
		this.resources = [];
		for (k = 0; k < status.vision.resources.length; k++) {
			r = status.vision.resources[k];
			this.resources.push(new Resource(r.id, r.x, r.y));
		}
	}

	Status.debug = function(status, otherText) {
		if (!otherText) {
			otherText = "(round " + status.round + ")";
		}
		console.log("<-- DEBUG STATUS " + otherText + " -->");
		console.log(JSON.stringify(status, null, 4));
		return console.log("</- DEBUG STATUS " + otherText + " -/>");
	};

	return Status;

})();

exports.Directions = {
	North: 'N',
	South: 'S',
	East: 'E',
	West: 'W'
};
