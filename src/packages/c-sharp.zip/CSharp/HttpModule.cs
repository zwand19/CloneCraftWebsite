﻿using Nancy;
using Nancy.IO;
using Newtonsoft.Json;
using System.Globalization;

namespace CloneCraft
{
    public class HttpModule : NancyModule
    {
        public Commander Commander;
        public HttpModule(Commander commander)
        {
            After.AddItemToEndOfPipeline(AddHeaders);
            Options["/api/heartbeat"] = x => "";
            Options["/api/turn"] = x => "";
            Get["/"] = x => "Server is up and running";
            Get["/api/heartbeat"] = x => "Heart is beating!";
            Post["/api/turn"] = x => ProcessStatus(Request.Body);
            Post["/api/matchStart"] = x => ProcessMatchStart(Request.Body);
            Post["/api/gameResults"] = x => ProcessGameResult(Request.Body);

            Commander = commander;
        }

        private static void AddHeaders(NancyContext context)
        {
            context.Response.Headers.Add("Access-Control-Allow-Origin", "*");
            context.Response.Headers.Add("Access-Control-Allow-Methods", "POST");
            context.Response.Headers.Add("Access-Control-Allow-Headers", "Accept, Origin, Content-type");
        }

        public string ProcessGameResult(RequestStream requestBody)
        {
            var length = int.Parse(requestBody.Length.ToString(CultureInfo.InvariantCulture));
            var bytes = new byte[length];
            requestBody.Read(bytes, 0, length);
            var json = System.Text.Encoding.UTF8.GetString(bytes);

            // Process the status
            var gameResult = JsonConvert.DeserializeObject<GameResult>(json);

            Commander.GameResult(gameResult);

            return "{}";
        }

        public string ProcessMatchStart(RequestStream requestBody)
        {
            var length = int.Parse(requestBody.Length.ToString(CultureInfo.InvariantCulture));
            var bytes = new byte[length];
            requestBody.Read(bytes, 0, length);
            var json = System.Text.Encoding.UTF8.GetString(bytes);

            // Process the status
            var bestOf = JsonConvert.DeserializeObject<MatchInfo>(json);

            Commander.StartingMatch(bestOf);

            return "{}";
        }

        public string ProcessStatus(RequestStream requestBody)
        {
            var length = int.Parse(requestBody.Length.ToString(CultureInfo.InvariantCulture));
            var bytes = new byte[length];
            requestBody.Read(bytes, 0, length);
            var json = System.Text.Encoding.UTF8.GetString(bytes);

            // Process the status
            var status = JsonConvert.DeserializeObject<BoardStatus>(json);

            // Create commands to do
            var commands = Commander.GetCommands(status);
            var response = JsonConvert.SerializeObject(commands);
            return response;
        }
    }
}