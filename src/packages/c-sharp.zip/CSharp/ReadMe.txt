﻿Don't make any customizations to CustomBootstrapper.cs or HttpModule.cs.

When you're ready to upload your code, simply zip the contents of the csharp folder and upload it. Immediately inside your zip folder should be your bin folder and your web.config.