﻿namespace CloneCraft
{
    public static class Constants
    {
        public const char EastDirection = 'E';
        public const char WestDirection = 'W';
        public const char SouthDirection = 'S';
        public const char NorthDirection = 'N';
    }
}