﻿namespace CloneCraft
{
    public class Resource : Entity
    {
    }
}