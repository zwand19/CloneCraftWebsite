﻿using Newtonsoft.Json;

namespace CloneCraft
{
    public class HandOffParams
    {
        public HandOffParams(int minionId)
        {
            MinionId = minionId;
        }
        [JsonProperty("minionId")]
        public int MinionId { get; set; }
    }
}