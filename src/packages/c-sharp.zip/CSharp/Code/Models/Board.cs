﻿using Newtonsoft.Json;

namespace CloneCraft
{
    public class Board
    {
        [JsonProperty("w")]
        public int Width { get; set; }
        [JsonProperty("h")]
        public int Height { get; set; }
    }
}