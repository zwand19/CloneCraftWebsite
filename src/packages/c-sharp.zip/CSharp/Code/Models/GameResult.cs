﻿using Newtonsoft.Json;

namespace CloneCraft
{
    public class GameResult
    {
        public string Id { get; set; }
        [JsonProperty("won")]
        public bool Won { get; set; }
        [JsonProperty("match_over")]
        public bool MatchOver { get; set; }
    }
}