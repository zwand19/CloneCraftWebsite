﻿using Newtonsoft.Json;

namespace CloneCraft
{
    public class MatchInfo
    {
        [JsonProperty("best_of")]
        public int BestOf { get; set; }
        [JsonProperty("opponent_name")]
        public string OpponentName { get; set; }
        [JsonProperty("tournament_id")]
        public string TournamentId { get; set; }
        [JsonProperty("game_ids")]
        public string[] GameIds { get; set; }
    }
}
